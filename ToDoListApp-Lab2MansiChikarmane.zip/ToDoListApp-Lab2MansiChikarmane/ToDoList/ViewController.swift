//
//  ViewController.swift
//  ToDoList
//
//  Created by Mansi Chikarmane on 5/4/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var image: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

}

